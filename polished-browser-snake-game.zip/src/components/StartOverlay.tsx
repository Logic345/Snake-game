import React from 'react';
import { Play, Zap, Trophy, Keyboard, Smartphone, Flame } from 'lucide-react';
import { HighScoreEntry, SpeedPreset } from '../types/game';

interface StartOverlayProps {
  preset: SpeedPreset;
  leaderboard: HighScoreEntry[];
  onSelectPreset: (preset: SpeedPreset) => void;
  onStartGame: () => void;
}

const PRESETS: { id: SpeedPreset; label: string; speedDesc: string; bonusDesc: string }[] = [
  { id: 'ARCADE', label: 'ARCADE', speedDesc: '8.5 CPS BASE', bonusDesc: '1.0x SCORE' },
  { id: 'TURBO', label: 'TURBO', speedDesc: '11.0 CPS BASE', bonusDesc: '1.3x SCORE' },
  { id: 'HYPER', label: 'HYPER', speedDesc: '13.5 CPS BASE', bonusDesc: '1.6x SCORE' },
];

export const StartOverlay: React.FC<StartOverlayProps> = ({
  preset,
  leaderboard,
  onSelectPreset,
  onStartGame,
}) => {
  const topThree = leaderboard.slice(0, 3);

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-3 sm:p-5 bg-[#08090D]/60 backdrop-blur-[8px] animate-fadeIn">
      <div className="w-full max-w-[460px] bg-[#11141D]/92 border border-[#1E2436] rounded-lg p-4 sm:p-6 shadow-[0_24px_60px_rgba(0,0,0,0.85),0_0_40px_rgba(0,255,102,0.08)] flex flex-col gap-4">
        {/* Top Header & Vector Emblem */}
        <div className="flex items-center justify-between border-b border-[#1E2436] pb-3.5">
          <div className="flex items-center gap-3">
            {/* Custom SVG Vector Snake Emblem */}
            <div className="w-11 h-11 rounded-md bg-[#0D0F16] border border-[#00FF66]/50 flex items-center justify-center shadow-[0_0_18px_rgba(0,255,102,0.22)] shrink-0">
              <svg viewBox="0 0 40 40" className="w-7 h-7">
                <path
                  d="M7 29 L7 18 L18 18 L18 10 L31 10"
                  fill="none"
                  stroke="#00E5FF"
                  strokeWidth="4.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <polygon points="35,10 28,5 28,15" fill="#00FF66" />
                <circle cx="9" cy="10" r="3.5" fill="#00FF66" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono-num uppercase tracking-[0.2em] px-1.5 py-0.5 rounded bg-[#00FF66]/15 text-[#00FF66] border border-[#00FF66]/40">
                  SYS.READY
                </span>
                <span className="text-[10px] font-mono-num text-[#8E98B0] tracking-widest">
                  60FPS VECTOR ENGINE
                </span>
              </div>
              <h1 className="font-display font-bold italic text-2xl sm:text-3xl tracking-tight text-[#F8FAFC] leading-none mt-1">
                VIPER <span className="text-[#00FF66] glow-green">//</span> DX-01
              </h1>
            </div>
          </div>
        </div>

        {/* Core Loop Brief */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-[#0D0F16]/90 border border-[#1E2436] rounded p-2 flex flex-col items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-[#00FF66] shadow-[0_0_10px_#00FF66] my-0.5" />
            <span className="font-mono-num font-bold text-[11px] text-[#F8FAFC]">EAT GREEN</span>
            <span className="text-[10px] text-[#8E98B0] leading-tight">Grow & ramp velocity</span>
          </div>
          <div className="bg-[#0D0F16]/90 border border-[#1E2436] rounded p-2 flex flex-col items-center gap-1">
            <Flame className="w-4 h-4 text-[#FFB800]" />
            <span className="font-mono-num font-bold text-[11px] text-[#FFB800]">CHAIN x16</span>
            <span className="text-[10px] text-[#8E98B0] leading-tight">Beat combo decay bar</span>
          </div>
          <div className="bg-[#0D0F16]/90 border border-[#1E2436] rounded p-2 flex flex-col items-center gap-1">
            <Zap className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-mono-num font-bold text-[11px] text-[#00E5FF]">OVERDRIVE</span>
            <span className="text-[10px] text-[#8E98B0] leading-tight">Hold Shift for 1.5x pts</span>
          </div>
        </div>

        {/* Speed Tier Selector */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-[0.12em] text-[#8E98B0]">
            <span>SELECT VELOCITY CLASS</span>
            <span className="font-mono-num text-[#00FF66]">Every 5th bite = Cluster Wave</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {PRESETS.map((item) => {
              const active = preset === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectPreset(item.id)}
                  className={`flex flex-col items-center justify-center py-2 px-2 rounded border transition-all cursor-pointer ${
                    active
                      ? 'bg-[#00FF66]/15 border-[#00FF66] text-[#F8FAFC] shadow-[0_0_16px_rgba(0,255,102,0.25)]'
                      : 'bg-[#0D0F16] border-[#1E2436] text-[#8E98B0] hover:border-[#4A5368] hover:text-[#F8FAFC]'
                  }`}
                >
                  <span className="font-display font-bold text-xs sm:text-sm tracking-wider">
                    {item.label}
                  </span>
                  <span className="font-mono-num text-[10px] text-[#00FF66] mt-0.5">
                    {item.bonusDesc}
                  </span>
                  <span className="font-mono-num text-[9px] text-[#8E98B0]">
                    {item.speedDesc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Mini Top-3 Cabinet High Scores */}
        <div className="bg-[#0D0F16]/90 border border-[#1E2436] rounded p-2.5">
          <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8E98B0] mb-1.5">
            <span className="flex items-center gap-1 text-[#FFB800]">
              <Trophy className="w-3 h-3" /> TOP CABINET RECORDS
            </span>
            <span>LOCAL STORAGE</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {topThree.map((entry, idx) => (
              <div
                key={entry.id}
                className="bg-[#11141D] border border-[#1E2436] rounded px-2 py-1.5 flex items-center justify-between"
              >
                <div className="flex items-center gap-1.5">
                  <span
                    className={`font-mono-num text-[10px] font-bold ${
                      idx === 0 ? 'text-[#00FF66]' : 'text-[#8E98B0]'
                    }`}
                  >
                    #{idx + 1}
                  </span>
                  <span className="font-mono-num text-xs font-extrabold text-[#F8FAFC]">
                    {entry.initials}
                  </span>
                </div>
                <span className="font-mono-num text-xs font-bold text-[#00FF66]">
                  {entry.score.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Primary Launch CTA */}
        <button
          type="button"
          onClick={onStartGame}
          className="w-full py-3.5 px-6 rounded bg-[#00FF66] hover:bg-[#1aff75] active:scale-[0.99] text-[#08090D] font-display font-bold text-base sm:text-lg tracking-wider uppercase flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(0,255,102,0.5)] transition-all cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current" />
          LAUNCH RUN
          <span className="font-mono-num text-xs font-extrabold px-2 py-0.5 rounded bg-[#08090D]/20 text-[#08090D] ml-1">
            SPACE / TAP
          </span>
        </button>

        {/* Control Hints Footer */}
        <div className="flex items-center justify-between text-[11px] text-[#8E98B0] pt-1 border-t border-[#1E2436]/70">
          <span className="inline-flex items-center gap-1.5">
            <Keyboard className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>WASD / Arrows + Shift Boost</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-[#00FF66]" />
            <span>Swipe Arena or D-Pad</span>
          </span>
        </div>
      </div>
    </div>
  );
};
