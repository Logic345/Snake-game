import React from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Home } from 'lucide-react';
import { RunStats } from '../types/game';

interface PauseOverlayProps {
  stats: RunStats;
  isMuted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onToggleMute: () => void;
  onQuitToTitle: () => void;
}

export const PauseOverlay: React.FC<PauseOverlayProps> = ({
  stats,
  isMuted,
  onResume,
  onRestart,
  onToggleMute,
  onQuitToTitle,
}) => {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-[#08090D]/75 backdrop-blur-[10px]">
      <div className="w-full max-w-[360px] bg-[#11141D]/95 border border-[#1E2436] rounded-lg p-5 shadow-[0_24px_60px_rgba(0,0,0,0.85)] flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#1E2436] pb-3">
          <div>
            <span className="text-[10px] font-mono-num uppercase tracking-[0.2em] text-[#FFB800]">
              SIMULATION HALTED
            </span>
            <h2 className="font-display font-bold italic text-2xl text-[#F8FAFC] tracking-tight">
              SYSTEM PAUSED
            </h2>
          </div>
          <span className="font-mono-num text-xs px-2 py-1 rounded bg-[#181C28] text-[#8E98B0] border border-[#1E2436]">
            ESC / P
          </span>
        </div>

        {/* Live Telemetry Snapshot */}
        <div className="grid grid-cols-3 gap-2 text-center bg-[#0D0F16] border border-[#1E2436] rounded p-2.5">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-[#8E98B0]">SCORE</div>
            <div className="font-mono-num font-bold text-sm text-[#00FF66] mt-0.5">
              {stats.score.toLocaleString()}
            </div>
          </div>
          <div className="border-x border-[#1E2436]">
            <div className="text-[10px] uppercase tracking-wider text-[#8E98B0]">LENGTH</div>
            <div className="font-mono-num font-bold text-sm text-[#00E5FF] mt-0.5">
              {stats.length}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-[#8E98B0]">PEAK CHAIN</div>
            <div className="font-mono-num font-bold text-sm text-[#FFB800] mt-0.5">
              x{stats.maxChain}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={onResume}
            className="w-full py-3 px-4 rounded bg-[#00FF66] hover:bg-[#1aff75] text-[#08090D] font-display font-bold text-base uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,255,102,0.4)] transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            RESUME RUN [SPACE]
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="w-full py-2.5 px-4 rounded bg-[#181C28] hover:bg-[#1E2436] border border-[#1E2436] hover:border-[#00FF66]/50 text-[#F8FAFC] font-display font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-[#00FF66]" />
            INSTANT RESTART [R]
          </button>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={onToggleMute}
              className="py-2 px-3 rounded bg-[#0D0F16] hover:bg-[#181C28] border border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC] text-xs font-mono-num font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-[#FF2A5F]" /> AUDIO OFF
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-[#00FF66]" /> AUDIO ON
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onQuitToTitle}
              className="py-2 px-3 rounded bg-[#0D0F16] hover:bg-[#181C28] border border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC] text-xs font-mono-num font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Home className="w-3.5 h-3.5" /> TITLE SCREEN
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
