import React from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Zap } from 'lucide-react';
import { Direction } from '../types/game';

interface TouchControlDockProps {
  currentDirection: Direction;
  isBoosting: boolean;
  onDirectionInput: (dir: Direction) => void;
  onSetBoost: (active: boolean) => void;
}

export const TouchControlDock: React.FC<TouchControlDockProps> = ({
  currentDirection,
  isBoosting,
  onDirectionInput,
  onSetBoost,
}) => {
  const handleDirPointerDown = (dir: Direction) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onDirectionInput(dir);
  };

  return (
    <div className="w-full max-w-[660px] px-3 pt-2 pb-1 flex items-center justify-between gap-4 select-none shrink-0">
      {/* Left: Tactical 4-Way D-Pad */}
      <div className="grid grid-cols-3 gap-1.5 w-[156px] h-[116px]">
        <div />
        <button
          type="button"
          onPointerDown={handleDirPointerDown('UP')}
          aria-label="Turn Up"
          className={`rounded border flex items-center justify-center active:scale-95 transition-transform cursor-pointer ${
            currentDirection === 'UP'
              ? 'bg-[#00FF66]/25 border-[#00FF66] text-[#00FF66] shadow-[0_0_12px_rgba(0,255,102,0.3)]'
              : 'bg-[#11141D] border-[#1E2436] text-[#F8FAFC]'
          }`}
        >
          <ChevronUp className="w-6 h-6" />
        </button>
        <div />

        <button
          type="button"
          onPointerDown={handleDirPointerDown('LEFT')}
          aria-label="Turn Left"
          className={`rounded border flex items-center justify-center active:scale-95 transition-transform cursor-pointer ${
            currentDirection === 'LEFT'
              ? 'bg-[#00FF66]/25 border-[#00FF66] text-[#00FF66] shadow-[0_0_12px_rgba(0,255,102,0.3)]'
              : 'bg-[#11141D] border-[#1E2436] text-[#F8FAFC]'
          }`}
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          type="button"
          onPointerDown={handleDirPointerDown('DOWN')}
          aria-label="Turn Down"
          className={`rounded border flex items-center justify-center active:scale-95 transition-transform cursor-pointer ${
            currentDirection === 'DOWN'
              ? 'bg-[#00FF66]/25 border-[#00FF66] text-[#00FF66] shadow-[0_0_12px_rgba(0,255,102,0.3)]'
              : 'bg-[#11141D] border-[#1E2436] text-[#F8FAFC]'
          }`}
        >
          <ChevronDown className="w-6 h-6" />
        </button>

        <button
          type="button"
          onPointerDown={handleDirPointerDown('RIGHT')}
          aria-label="Turn Right"
          className={`rounded border flex items-center justify-center active:scale-95 transition-transform cursor-pointer ${
            currentDirection === 'RIGHT'
              ? 'bg-[#00FF66]/25 border-[#00FF66] text-[#00FF66] shadow-[0_0_12px_rgba(0,255,102,0.3)]'
              : 'bg-[#11141D] border-[#1E2436] text-[#F8FAFC]'
          }`}
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Center Swipe Tip */}
      <div className="hidden xs:flex flex-col items-center text-center text-[10px] font-mono-num text-[#4A5368]">
        <span>SWIPE ARENA</span>
        <span>OR TAP D-PAD</span>
      </div>

      {/* Right: Overdrive Boost Pad */}
      <button
        type="button"
        onPointerDown={(e) => {
          e.preventDefault();
          onSetBoost(true);
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          onSetBoost(false);
        }}
        onPointerLeave={() => onSetBoost(false)}
        onPointerCancel={() => onSetBoost(false)}
        className={`h-[96px] px-5 rounded-lg border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
          isBoosting
            ? 'bg-[#00E5FF]/25 border-[#00E5FF] text-[#00E5FF] shadow-[0_0_24px_rgba(0,229,255,0.4)] scale-95'
            : 'bg-[#11141D] border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC]'
        }`}
      >
        <Zap className={`w-6 h-6 ${isBoosting ? 'fill-current text-[#00E5FF]' : 'text-[#00E5FF]'}`} />
        <span className="font-display font-bold text-xs tracking-wider uppercase text-[#F8FAFC]">
          BOOST
        </span>
        <span className="font-mono-num text-[9px] text-[#00E5FF]">1.5x SCORE</span>
      </button>
    </div>
  );
};
