import React from 'react';
import { Volume2, VolumeX, Pause, Play, RotateCcw, Gamepad2, Zap } from 'lucide-react';
import { GameState, RunStats, SpeedPreset } from '../types/game';

interface TopHudBarProps {
  stats: RunStats;
  bestScore: number;
  gameState: GameState;
  preset: SpeedPreset;
  isMuted: boolean;
  showTouchControls: boolean;
  onToggleMute: () => void;
  onTogglePause: () => void;
  onRestart: () => void;
  onToggleTouchControls: () => void;
}

export const TopHudBar: React.FC<TopHudBarProps> = ({
  stats,
  bestScore,
  gameState,
  preset,
  isMuted,
  showTouchControls,
  onToggleMute,
  onTogglePause,
  onRestart,
  onToggleTouchControls,
}) => {
  const isNewRecord = stats.score > 0 && stats.score >= bestScore;
  const displayBest = Math.max(bestScore, stats.score);

  return (
    <header className="w-full max-w-[660px] px-2 sm:px-0 mb-2 select-none shrink-0">
      <div className="bg-[#11141D]/90 backdrop-blur-md border border-[#1E2436] rounded-md px-3 py-2 flex items-center justify-between gap-2 shadow-[0_10px_30px_rgba(0,0,0,0.65)]">
        {/* Left: Brand Tag + Current Score */}
        <div className="flex items-center gap-3 sm:gap-5 min-w-0">
          <div className="hidden sm:flex flex-col border-r border-[#1E2436] pr-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse shadow-[0_0_8px_#00FF66]" />
              <span className="font-display font-bold text-xs tracking-wider text-[#F8FAFC]">
                VIPER<span className="text-[#00FF66]">//</span>DX
              </span>
            </div>
            <span className="font-mono-num text-[10px] tracking-widest text-[#8E98B0] uppercase mt-0.5">
              {preset} SYS
            </span>
          </div>

          {/* Live Score */}
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-semibold tracking-[0.12em] uppercase text-[#8E98B0]">
                SCORE
              </span>
              {stats.length > 3 && (
                <span className="text-[10px] font-mono-num px-1 py-0.2 rounded bg-[#181C28] text-[#00E5FF] border border-[#00E5FF]/30">
                  LEN {stats.length}
                </span>
              )}
            </div>
            <div className="font-mono-num font-extrabold text-xl sm:text-2xl leading-none tracking-tight text-[#F8FAFC] mt-0.5">
              {stats.score.toLocaleString()}
            </div>
          </div>

          {/* Best Score */}
          <div className="flex flex-col border-l border-[#1E2436] pl-3 sm:pl-4">
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-semibold tracking-[0.12em] uppercase text-[#8E98B0]">
                BEST
              </span>
              {isNewRecord && (
                <span className="text-[9px] font-mono-num font-bold px-1 rounded bg-[#00FF66]/20 text-[#00FF66] border border-[#00FF66]/50 animate-pulse">
                  RECORD
                </span>
              )}
            </div>
            <div
              className={`font-mono-num font-bold text-base sm:text-xl leading-none mt-0.5 ${
                isNewRecord ? 'text-[#00FF66] glow-green' : 'text-[#8E98B0]'
              }`}
            >
              {displayBest.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Center/Right: Speed & Chain Combo Telemetry */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex flex-col items-end min-w-[92px] sm:min-w-[118px]">
            <div className="flex items-center gap-1.5">
              {stats.isBoosting && (
                <span className="inline-flex items-center gap-0.5 text-[10px] font-mono-num font-bold px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/50">
                  <Zap className="w-2.5 h-2.5 fill-current" />
                  BOOST
                </span>
              )}
              <span className="font-mono-num text-xs font-bold text-[#8E98B0]">
                {stats.speedMultiplier.toFixed(1)}x
              </span>
              <span
                className={`font-mono-num text-xs sm:text-sm font-extrabold px-1.5 py-0.5 rounded border transition-colors ${
                  stats.currentChain >= 5
                    ? 'bg-[#FFB800]/20 text-[#FFB800] border-[#FFB800]/60 glow-amber'
                    : stats.currentChain >= 2
                    ? 'bg-[#00FF66]/20 text-[#00FF66] border-[#00FF66]/50 glow-green'
                    : 'bg-[#181C28] text-[#8E98B0] border-[#1E2436]'
                }`}
              >
                x{stats.currentChain}
              </span>
            </div>

            {/* Combo Decay Progress Bar */}
            <div className="w-full h-1.5 bg-[#08090D] rounded-full overflow-hidden mt-1 border border-[#1E2436]">
              <div
                className={`h-full transition-none ${
                  stats.currentChain >= 5
                    ? 'bg-[#FFB800] shadow-[0_0_8px_#FFB800]'
                    : 'bg-[#00FF66] shadow-[0_0_8px_#00FF66]'
                }`}
                style={{
                  width: `${Math.max(0, Math.min(100, stats.chainTimer * 100))}%`,
                }}
              />
            </div>
          </div>

          {/* Hardware Action Buttons */}
          <div className="flex items-center gap-1 border-l border-[#1E2436] pl-2">
            <button
              type="button"
              onClick={onToggleTouchControls}
              title="Toggle On-Screen D-Pad"
              className={`p-2 rounded border transition-colors cursor-pointer ${
                showTouchControls
                  ? 'bg-[#00FF66]/15 border-[#00FF66]/60 text-[#00FF66]'
                  : 'bg-[#181C28] border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC] hover:border-[#4A5368]'
              }`}
            >
              <Gamepad2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onToggleMute}
              title={isMuted ? 'Unmute Synth (M)' : 'Mute Synth (M)'}
              className="p-2 rounded bg-[#181C28] border border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC] hover:border-[#4A5368] transition-colors cursor-pointer"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-[#FF2A5F]" /> : <Volume2 className="w-4 h-4 text-[#00FF66]" />}
            </button>

            {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
              <>
                <button
                  type="button"
                  onClick={onRestart}
                  title="Instant Restart (R)"
                  className="p-2 rounded bg-[#181C28] border border-[#1E2436] text-[#8E98B0] hover:text-[#00FF66] hover:border-[#00FF66]/50 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onTogglePause}
                  title={gameState === 'PAUSED' ? 'Resume (P / Space)' : 'Pause (P / Esc)'}
                  className={`p-2 rounded border transition-colors cursor-pointer ${
                    gameState === 'PAUSED'
                      ? 'bg-[#00FF66] text-[#08090D] border-[#00FF66]'
                      : 'bg-[#181C28] border-[#1E2436] text-[#F8FAFC] hover:border-[#00FF66]/50'
                  }`}
                >
                  {gameState === 'PAUSED' ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
