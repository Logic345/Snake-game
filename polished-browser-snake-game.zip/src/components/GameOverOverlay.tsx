import React, { useState } from 'react';
import { RotateCcw, Trophy, Sparkles, Home, Trash2, Check } from 'lucide-react';
import { HighScoreEntry, RunStats } from '../types/game';
import { formatRelativeTime } from '../utils/storage';

interface GameOverOverlayProps {
  stats: RunStats;
  leaderboard: HighScoreEntry[];
  newRecordId: string | null;
  newRecordRank: number | null;
  initialCallsign: string;
  deathReason: string;
  onUpdateInitials: (initials: string) => void;
  onRestart: () => void;
  onQuitToTitle: () => void;
  onResetLeaderboard: () => void;
}

export const GameOverOverlay: React.FC<GameOverOverlayProps> = ({
  stats,
  leaderboard,
  newRecordId,
  newRecordRank,
  initialCallsign,
  deathReason,
  onUpdateInitials,
  onRestart,
  onQuitToTitle,
  onResetLeaderboard,
}) => {
  const [callsign, setCallsign] = useState(initialCallsign.toUpperCase().slice(0, 3));
  const [isEditingCallsign, setIsEditingCallsign] = useState(false);

  const handleCallsignChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3);
    setCallsign(raw);
    if (raw.length > 0) {
      onUpdateInitials(raw.padEnd(3, 'A'));
    }
  };

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-2.5 sm:p-4 bg-[#08090D]/80 backdrop-blur-[10px] animate-fadeIn">
      <div className="w-full max-w-[460px] max-h-full overflow-y-auto bg-[#11141D]/95 border border-[#1E2436] rounded-lg p-4 sm:p-5 shadow-[0_25px_70px_rgba(0,0,0,0.9)] flex flex-col gap-3.5">
        {/* Header Status */}
        <div className="flex items-start justify-between border-b border-[#1E2436] pb-3">
          <div>
            {newRecordRank ? (
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#00FF66]/15 border border-[#00FF66]/50 text-[#00FF66] text-[10px] font-mono-num font-bold uppercase tracking-widest mb-1">
                <Sparkles className="w-3 h-3" /> NEW TOP 5 RECORD — RANK #{newRecordRank}
              </div>
            ) : (
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#FF2A5F]/15 border border-[#FF2A5F]/40 text-[#FF2A5F] text-[10px] font-mono-num font-bold uppercase tracking-widest mb-1">
                {deathReason || 'SIGNAL TERMINATED'}
              </div>
            )}
            <h2
              className={`font-display font-bold italic text-2xl sm:text-3xl tracking-tight leading-none ${
                newRecordRank ? 'text-[#00FF66] glow-green' : 'text-[#F8FAFC]'
              }`}
            >
              {newRecordRank ? 'HIGH SCORE LOGGED' : 'GAME OVER'}
            </h2>
          </div>

          {/* Final Score Highlight */}
          <div className="text-right">
            <span className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8E98B0] block">
              FINAL SCORE
            </span>
            <span className="font-mono-num font-extrabold text-2xl sm:text-3xl text-[#F8FAFC] leading-none">
              {stats.score.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Run Telemetry Metrics */}
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="bg-[#0D0F16] border border-[#1E2436] rounded p-2">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-[#8E98B0] block">
              GREEN EATEN
            </span>
            <span className="font-mono-num font-bold text-sm sm:text-base text-[#00FF66]">
              {stats.foodEaten}
            </span>
          </div>
          <div className="bg-[#0D0F16] border border-[#1E2436] rounded p-2">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-[#8E98B0] block">
              MAX LENGTH
            </span>
            <span className="font-mono-num font-bold text-sm sm:text-base text-[#00E5FF]">
              {stats.length}
            </span>
          </div>
          <div className="bg-[#0D0F16] border border-[#1E2436] rounded p-2">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-[#8E98B0] block">
              PEAK CHAIN
            </span>
            <span className="font-mono-num font-bold text-sm sm:text-base text-[#FFB800]">
              x{stats.maxChain}
            </span>
          </div>
          <div className="bg-[#0D0F16] border border-[#1E2436] rounded p-2">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-[#8E98B0] block">
              TOP SPEED
            </span>
            <span className="font-mono-num font-bold text-sm sm:text-base text-[#F8FAFC]">
              {stats.speedMultiplier.toFixed(1)}x
            </span>
          </div>
        </div>

        {/* Inline 3-Char Callsign Editor when player achieves a Top 5 High Score */}
        {newRecordId && (
          <div className="bg-[#00FF66]/10 border border-[#00FF66]/50 rounded-md px-3 py-2 flex items-center justify-between gap-2">
            <div className="flex flex-col">
              <span className="text-[10px] font-mono-num font-bold uppercase tracking-wider text-[#00FF66]">
                ENTER 3-CHAR CALLSIGN
              </span>
              <span className="text-[11px] text-[#8E98B0]">
                Saved automatically to local leaderboard
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <input
                type="text"
                maxLength={3}
                value={callsign}
                onFocus={() => setIsEditingCallsign(true)}
                onBlur={() => setIsEditingCallsign(false)}
                onChange={handleCallsignChange}
                onKeyDown={(e) => {
                  e.stopPropagation();
                  if (e.key === 'Enter') {
                    (e.target as HTMLInputElement).blur();
                  }
                }}
                className="w-20 py-1 px-2 text-center font-mono-num font-extrabold text-lg tracking-[0.25em] uppercase rounded bg-[#08090D] border-2 border-[#00FF66] text-[#00FF66] focus:outline-none shadow-[0_0_12px_rgba(0,255,102,0.3)]"
              />
              {isEditingCallsign && (
                <button
                  type="button"
                  onClick={() => setIsEditingCallsign(false)}
                  className="p-1.5 rounded bg-[#00FF66] text-[#08090D] cursor-pointer"
                  title="Confirm Callsign"
                >
                  <Check className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Top 5 Local High-Score Leaderboard Table */}
        <div className="bg-[#0D0F16] border border-[#1E2436] rounded-md p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#FFB800]">
              <Trophy className="w-3.5 h-3.5" /> TOP 5 LOCAL HIGH SCORES
            </span>
            <button
              type="button"
              onClick={onResetLeaderboard}
              title="Reset Leaderboard to Factory Defaults"
              className="inline-flex items-center gap-1 text-[10px] font-mono-num text-[#4A5368] hover:text-[#FF2A5F] transition-colors cursor-pointer"
            >
              <Trash2 className="w-3 h-3" /> RESET
            </button>
          </div>

          <div className="flex flex-col gap-1.5">
            {leaderboard.map((entry, idx) => {
              const isCurrentRun = entry.id === newRecordId;
              return (
                <div
                  key={entry.id}
                  className={`flex items-center justify-between px-2.5 py-1.5 rounded border text-xs font-mono-num transition-all ${
                    isCurrentRun
                      ? 'bg-[#00FF66]/15 border-[#00FF66] text-[#F8FAFC] shadow-[0_0_14px_rgba(0,255,102,0.2)]'
                      : idx === 0
                      ? 'bg-[#11141D] border-[#FFB800]/40 text-[#F8FAFC]'
                      : 'bg-[#11141D]/70 border-[#1E2436] text-[#8E98B0]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-5 font-extrabold ${
                        isCurrentRun
                          ? 'text-[#00FF66]'
                          : idx === 0
                          ? 'text-[#FFB800]'
                          : 'text-[#4A5368]'
                      }`}
                    >
                      #{idx + 1}
                    </span>
                    <span className="font-extrabold tracking-wider text-[#F8FAFC] w-10">
                      {entry.initials}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#08090D] text-[#00E5FF] border border-[#1E2436]">
                      LEN {entry.maxLength}
                    </span>
                    <span className="hidden sm:inline-block text-[10px] px-1.5 py-0.5 rounded bg-[#08090D] text-[#FFB800] border border-[#1E2436]">
                      x{entry.maxChain}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-[#4A5368]">
                      {formatRelativeTime(entry.timestamp)}
                    </span>
                    <span
                      className={`font-extrabold text-sm ${
                        isCurrentRun || idx === 0 ? 'text-[#00FF66]' : 'text-[#F8FAFC]'
                      }`}
                    >
                      {entry.score.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Instant Restart CTA + Title Screen Button */}
        <div className="flex items-center gap-2 pt-0.5">
          <button
            type="button"
            onClick={onQuitToTitle}
            className="py-3 px-3.5 rounded bg-[#181C28] hover:bg-[#1E2436] border border-[#1E2436] text-[#8E98B0] hover:text-[#F8FAFC] transition-colors cursor-pointer"
            title="Return to Title Screen"
          >
            <Home className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="flex-1 py-3 px-5 rounded bg-[#00FF66] hover:bg-[#1aff75] active:scale-[0.99] text-[#08090D] font-display font-bold text-base sm:text-lg uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(0,255,102,0.45)] transition-all cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            PLAY AGAIN
            <span className="font-mono-num text-xs font-extrabold px-2 py-0.5 rounded bg-[#08090D]/20 text-[#08090D] ml-1">
              SPACE / ENTER
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
