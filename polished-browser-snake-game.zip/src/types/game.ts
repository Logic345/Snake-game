export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'DYING' | 'GAMEOVER';

export type SpeedPreset = 'ARCADE' | 'TURBO' | 'HYPER';

export interface GridPoint {
  x: number;
  y: number;
}

export interface FoodItem {
  id: number;
  x: number;
  y: number;
  type: 'PRIMARY_GREEN' | 'CLUSTER_GREEN';
  spawnTime: number;
  expiresAt: number | null; // null for primary green food (never expires), timestamp for bonus cluster orbs
  value: number;
  pulsePhase: number;
}

export interface Particle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  shape: 'SQUARE' | 'DIAMOND' | 'SPARK';
  rotation: number;
  vRot: number;
}

export interface FloatingText {
  active: boolean;
  x: number;
  y: number;
  vy: number;
  text: string;
  subtext?: string;
  color: string;
  life: number;
  maxLife: number;
  scale: number;
}

export interface GridShockwave {
  active: boolean;
  x: number; // grid coordinate x
  y: number; // grid coordinate y
  radius: number;
  maxRadius: number;
  color: string;
  life: number;
  maxLife: number;
}

export interface HighScoreEntry {
  id: string;
  initials: string;
  score: number;
  maxChain: number;
  maxLength: number;
  peakSpeed: number;
  preset: SpeedPreset;
  timestamp: number;
  isUser?: boolean;
}

export interface RunStats {
  score: number;
  foodEaten: number;
  maxChain: number;
  currentChain: number;
  chainTimer: number; // 0 to 1 normalized
  length: number;
  speedMultiplier: number;
  isBoosting: boolean;
  closeCalls: number;
  durationSec: number;
}
