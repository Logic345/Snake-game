import { HighScoreEntry } from '../types/game';

const LEADERBOARD_KEY = 'viper_dx_leaderboard_v1';
const INITIALS_KEY = 'viper_dx_last_initials';

const DEFAULT_LEADERBOARD: HighScoreEntry[] = [
  {
    id: 'seed-1',
    initials: 'VEX',
    score: 4850,
    maxChain: 9,
    maxLength: 28,
    peakSpeed: 2.4,
    preset: 'TURBO',
    timestamp: Date.now() - 1000 * 60 * 60 * 18,
  },
  {
    id: 'seed-2',
    initials: 'KAI',
    score: 3200,
    maxChain: 7,
    maxLength: 22,
    peakSpeed: 2.1,
    preset: 'ARCADE',
    timestamp: Date.now() - 1000 * 60 * 60 * 11,
  },
  {
    id: 'seed-3',
    initials: 'NYX',
    score: 2150,
    maxChain: 6,
    maxLength: 17,
    peakSpeed: 1.8,
    preset: 'ARCADE',
    timestamp: Date.now() - 1000 * 60 * 60 * 5,
  },
  {
    id: 'seed-4',
    initials: 'ZERO',
    score: 1350,
    maxChain: 4,
    maxLength: 13,
    peakSpeed: 1.5,
    preset: 'ARCADE',
    timestamp: Date.now() - 1000 * 60 * 95,
  },
  {
    id: 'seed-5',
    initials: 'ACE',
    score: 650,
    maxChain: 3,
    maxLength: 9,
    peakSpeed: 1.3,
    preset: 'ARCADE',
    timestamp: Date.now() - 1000 * 60 * 30,
  },
];

export function getLeaderboard(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) {
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(DEFAULT_LEADERBOARD));
      return [...DEFAULT_LEADERBOARD];
    }
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return [...DEFAULT_LEADERBOARD];
    }
    return parsed
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map((item) => ({
        ...item,
        initials: (item.initials || 'VIP').slice(0, 3).toUpperCase(),
      }));
  } catch {
    return [...DEFAULT_LEADERBOARD];
  }
}

export function getSavedInitials(): string {
  try {
    const saved = localStorage.getItem(INITIALS_KEY);
    if (saved && /^[A-Z0-9]{1,3}$/.test(saved)) {
      return saved.padEnd(3, 'A').slice(0, 3);
    }
  } catch {
    // ignore
  }
  return 'VIP';
}

export function saveInitials(initials: string): void {
  try {
    const clean = initials.toUpperCase().replace(/[^A-Z0-9]/g, 'A').padEnd(3, 'A').slice(0, 3);
    localStorage.setItem(INITIALS_KEY, clean);
  } catch {
    // ignore
  }
}

export function qualifiesForLeaderboard(score: number): boolean {
  if (score <= 0) return false;
  const board = getLeaderboard();
  if (board.length < 5) return true;
  return score > board[board.length - 1].score;
}

export function insertHighScore(entry: Omit<HighScoreEntry, 'id' | 'timestamp'>): {
  board: HighScoreEntry[];
  insertedId: string;
  rank: number;
} {
  const current = getLeaderboard();
  const insertedId = `run-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const newEntry: HighScoreEntry = {
    ...entry,
    id: insertedId,
    initials: entry.initials.toUpperCase().slice(0, 3),
    timestamp: Date.now(),
    isUser: true,
  };

  const updated = [...current, newEntry]
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  const rank = updated.findIndex((item) => item.id === insertedId) + 1;

  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }

  return { board: updated, insertedId, rank };
}

export function updateHighScoreInitials(id: string, initials: string): HighScoreEntry[] {
  const clean = initials.toUpperCase().replace(/[^A-Z0-9]/g, 'A').padEnd(3, 'A').slice(0, 3);
  saveInitials(clean);
  const current = getLeaderboard();
  const updated = current.map((item) =>
    item.id === id ? { ...item, initials: clean } : item
  );
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}

export function resetLeaderboardToDefault(): HighScoreEntry[] {
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(DEFAULT_LEADERBOARD));
  } catch {
    // ignore
  }
  return [...DEFAULT_LEADERBOARD];
}

export function formatRelativeTime(timestamp: number): string {
  const diffSec = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (diffSec < 45) return 'JUST NOW';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}M AGO`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}H AGO`;
  const diffDays = Math.floor(diffHr / 24);
  return `${diffDays}D AGO`;
}
