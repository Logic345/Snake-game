import {
  Direction,
  FloatingText,
  FoodItem,
  GridPoint,
  GridShockwave,
  Particle,
} from '../types/game';

export interface RenderContextData {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  gridSize: number;
  now: number;
  segments: GridPoint[];
  prevSegments: GridPoint[];
  moveProgress: number;
  direction: Direction;
  foods: FoodItem[];
  particles: Particle[];
  floatingTexts: FloatingText[];
  shockwaves: GridShockwave[];
  digestPulses: number[]; // progress 0..1 of food pulse travelling head->tail
  isBoosting: boolean;
  speedMultiplier: number;
  currentChain: number;
  chainTimer: number;
  borderPulse: number; // 0..1 green pulse on eat
  dangerPulse: number; // 0..1 crimson flash on crash/close call
  shakeOffsetX: number;
  shakeOffsetY: number;
  isDying: boolean;
  isDemo: boolean;
}

// Helper to interpolate between two hex colors
function lerpColor(hexA: string, hexB: string, t: number): string {
  const clampT = Math.max(0, Math.min(1, t));
  const a = parseInt(hexA.slice(1), 16);
  const b = parseInt(hexB.slice(1), 16);
  const rA = (a >> 16) & 255;
  const gA = (a >> 8) & 255;
  const bA = a & 255;
  const rB = (b >> 16) & 255;
  const gB = (b >> 8) & 255;
  const bB = b & 255;
  const r = Math.round(rA + (rB - rA) * clampT);
  const g = Math.round(gA + (gB - gA) * clampT);
  const bl = Math.round(bA + (bB - bA) * clampT);
  return `rgb(${r}, ${g}, ${bl})`;
}

export function renderGameCanvas(data: RenderContextData): void {
  const {
    ctx,
    width,
    height,
    gridSize,
    now,
    segments,
    prevSegments,
    moveProgress,
    direction,
    foods,
    particles,
    floatingTexts,
    shockwaves,
    digestPulses,
    isBoosting,
    speedMultiplier,
    currentChain,
    borderPulse,
    dangerPulse,
    shakeOffsetX,
    shakeOffsetY,
    isDying,
  } = data;

  const cellSize = width / gridSize;

  ctx.save();

  // Clear outer canvas void
  ctx.fillStyle = '#0D0F16';
  ctx.fillRect(0, 0, width, height);

  // Apply directional camera screen shake
  if (shakeOffsetX !== 0 || shakeOffsetY !== 0) {
    ctx.translate(shakeOffsetX, shakeOffsetY);
  }

  // 1. Subtle radial ambient glow under primary green food
  const primaryFood = foods.find((f) => f.type === 'PRIMARY_GREEN') || foods[0];
  if (primaryFood) {
    const fx = (primaryFood.x + 0.5) * cellSize;
    const fy = (primaryFood.y + 0.5) * cellSize;
    const ambGrad = ctx.createRadialGradient(fx, fy, cellSize * 0.2, fx, fy, cellSize * 5.5);
    ambGrad.addColorStop(0, 'rgba(0, 255, 102, 0.13)');
    ambGrad.addColorStop(0.5, 'rgba(0, 255, 102, 0.04)');
    ambGrad.addColorStop(1, 'rgba(0, 255, 102, 0)');
    ctx.fillStyle = ambGrad;
    ctx.fillRect(0, 0, width, height);

    // Subtle target-lock axis lines for instant visual acquisition
    ctx.strokeStyle = 'rgba(0, 255, 102, 0.065)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(fx, 0);
    ctx.lineTo(fx, height);
    ctx.moveTo(0, fy);
    ctx.lineTo(width, fy);
    ctx.stroke();
  }

  // 2. Reactive Phosphor Grid Matrix & Shockwaves
  for (let gx = 1; gx < gridSize; gx++) {
    for (let gy = 1; gy < gridSize; gy++) {
      let px = gx * cellSize;
      let py = gy * cellSize;
      let waveIntensity = 0;

      for (let s = 0; s < shockwaves.length; s++) {
        const sw = shockwaves[s];
        if (!sw.active) continue;
        const dx = gx - (sw.x + 0.5);
        const dy = gy - (sw.y + 0.5);
        const dist = Math.sqrt(dx * dx + dy * dy);
        const ringDiff = Math.abs(dist - sw.radius);
        if (ringDiff < 1.6) {
          const factor = (1 - ringDiff / 1.6) * (sw.life / sw.maxLife);
          waveIntensity = Math.max(waveIntensity, factor);
          if (dist > 0.01) {
            px += (dx / dist) * factor * 4.5;
            py += (dy / dist) * factor * 4.5;
          }
        }
      }

      if (waveIntensity > 0.05) {
        ctx.fillStyle = `rgba(0, 255, 102, ${0.2 + waveIntensity * 0.75})`;
        const dotSize = 2 + waveIntensity * 2.5;
        ctx.fillRect(px - dotSize * 0.5, py - dotSize * 0.5, dotSize, dotSize);
      } else {
        ctx.fillStyle = '#181C28';
        ctx.fillRect(px - 1, py - 1, 2, 2);
      }
    }
  }

  // Subtle tactical grid sectors (every 4 cells)
  ctx.strokeStyle = 'rgba(30, 36, 54, 0.42)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 4; i < gridSize; i += 4) {
    const pos = i * cellSize;
    ctx.moveTo(pos, 0);
    ctx.lineTo(pos, height);
    ctx.moveTo(0, pos);
    ctx.lineTo(width, pos);
  }
  ctx.stroke();

  // 3. Draw Expanding Shockwave Rings
  for (let i = 0; i < shockwaves.length; i++) {
    const sw = shockwaves[i];
    if (!sw.active) continue;
    const alpha = Math.max(0, (sw.life / sw.maxLife) * 0.45);
    ctx.strokeStyle = sw.color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(
      (sw.x + 0.5) * cellSize,
      (sw.y + 0.5) * cellSize,
      sw.radius * cellSize,
      0,
      Math.PI * 2
    );
    ctx.stroke();
  }
  ctx.globalAlpha = 1;

  // 4. Draw Green Food Items (Primary & Bonus Cluster Orbs)
  for (let i = 0; i < foods.length; i++) {
    const food = foods[i];
    const cx = (food.x + 0.5) * cellSize;
    const cy = (food.y + 0.5) * cellSize;
    const pulse = Math.sin(now * 0.008 + food.pulsePhase) * 0.16 + 1;

    if (food.type === 'PRIMARY_GREEN') {
      // Outer rotating tactical diamond reticle
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(now * 0.0022);
      const reticleSize = cellSize * 0.62 * pulse;
      ctx.strokeStyle = 'rgba(0, 255, 102, 0.55)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(-reticleSize * 0.5, -reticleSize * 0.5, reticleSize, reticleSize);
      ctx.restore();

      // Secondary counter-rotating diamond
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-now * 0.0035 + Math.PI / 4);
      const innerReticle = cellSize * 0.48;
      ctx.strokeStyle = '#00FF66';
      ctx.lineWidth = 1.8;
      ctx.strokeRect(-innerReticle * 0.5, -innerReticle * 0.5, innerReticle, innerReticle);
      ctx.restore();

      // Intense neon green glow core
      ctx.save();
      ctx.shadowColor = '#00FF66';
      ctx.shadowBlur = 18;
      ctx.fillStyle = '#00FF66';
      ctx.beginPath();
      ctx.arc(cx, cy, cellSize * 0.28 * pulse, 0, Math.PI * 2);
      ctx.fill();

      // Hyper-bright white-mint center core
      ctx.fillStyle = '#CCFFDF';
      ctx.beginPath();
      ctx.arc(cx, cy, cellSize * 0.14 * pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else {
      // CLUSTER_GREEN bonus energy cell
      const remainingRatio = food.expiresAt
        ? Math.max(0, Math.min(1, (food.expiresAt - now) / 6500))
        : 1;
      // Blink fast when about to expire
      if (remainingRatio < 0.25 && Math.floor(now / 80) % 2 === 0) {
        continue;
      }

      ctx.save();
      ctx.translate(cx, cy);

      // Expiration countdown ring
      ctx.strokeStyle = 'rgba(0, 255, 157, 0.45)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, cellSize * 0.44, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * remainingRatio);
      ctx.stroke();

      ctx.rotate(now * 0.004 + food.pulsePhase);
      ctx.shadowColor = '#00FF9D';
      ctx.shadowBlur = 14;
      ctx.fillStyle = '#00FF66';
      const s = cellSize * 0.36 * pulse;
      ctx.fillRect(-s * 0.5, -s * 0.5, s, s);

      ctx.fillStyle = '#FFFFFF';
      const innerS = s * 0.45;
      ctx.fillRect(-innerS * 0.5, -innerS * 0.5, innerS, innerS);
      ctx.restore();
    }
  }

  // 5. Compute Interpolated Snake Coordinates
  if (segments.length > 0 && !isDying) {
    const interpPoints: { x: number; y: number }[] = [];
    for (let i = 0; i < segments.length; i++) {
      const curr = segments[i];
      const prev = prevSegments[i] || curr;
      const ix = prev.x + (curr.x - prev.x) * moveProgress;
      const iy = prev.y + (curr.y - prev.y) * moveProgress;
      interpPoints.push({
        x: (ix + 0.5) * cellSize,
        y: (iy + 0.5) * cellSize,
      });
    }

    // 5a. Boost / High-Speed Ghost Trail
    if (isBoosting || speedMultiplier >= 1.6) {
      ctx.save();
      ctx.globalAlpha = isBoosting ? 0.28 : 0.14;
      for (let i = 0; i < Math.min(interpPoints.length, 6); i++) {
        const prev = prevSegments[i] || segments[i];
        const gx = (prev.x + 0.5) * cellSize;
        const gy = (prev.y + 0.5) * cellSize;
        const r = cellSize * 0.36 * (1 - i * 0.12);
        ctx.fillStyle = isBoosting ? '#00E5FF' : '#00FF66';
        ctx.beginPath();
        ctx.arc(gx, gy, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 5b. Render Snake Body Segments (from tail to neck so head overlaps cleanly)
    const totalSegs = interpPoints.length;
    for (let i = totalSegs - 1; i >= 1; i--) {
      const p1 = interpPoints[i];
      const p2 = interpPoints[i - 1];
      const ratio = i / Math.max(1, totalSegs - 1); // 0 near head, 1 at tail

      // Color gradient: #00E5FF (Cyan near head) -> #00FF66 (Neon Green mid) -> #009E52 (Deep Emerald tail)
      const segColor =
        ratio < 0.45
          ? lerpColor('#00E5FF', '#00FF66', ratio / 0.45)
          : lerpColor('#00FF66', '#008F4C', (ratio - 0.45) / 0.55);

      // Calculate digestive pulse swell if an eaten-food wave is passing this segment
      let swell = 0;
      for (let d = 0; d < digestPulses.length; d++) {
        const pulseIdx = digestPulses[d] * (totalSegs - 1);
        const dist = Math.abs(i - pulseIdx);
        if (dist < 2.2) {
          swell = Math.max(swell, (1 - dist / 2.2) * 0.38);
        }
      }

      // Taper tail smoothly
      const taper = i >= totalSegs - 3 ? 0.58 + (totalSegs - 1 - i) * 0.14 : 0.86;
      const thickness = cellSize * Math.min(0.95, taper + swell);

      // Draw capsule segment between p1 and p2
      ctx.save();
      ctx.strokeStyle = swell > 0.1 ? '#CCFFDF' : segColor;
      ctx.lineWidth = thickness;
      ctx.lineCap = 'round';
      if (i <= 3 || swell > 0.15) {
        ctx.shadowColor = swell > 0.15 ? '#00FF66' : '#00E5FF';
        ctx.shadowBlur = swell > 0.15 ? 14 : 8;
      }
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Inner high-voltage spine core line
      ctx.strokeStyle = swell > 0.1 ? '#FFFFFF' : 'rgba(248, 250, 252, 0.38)';
      ctx.lineWidth = Math.max(1.5, thickness * 0.24);
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      ctx.restore();
    }

    // 5c. Render Articulated Cyber-Viper Head
    const headPt = interpPoints[0];
    let headAngle = 0;
    if (direction === 'RIGHT') headAngle = 0;
    else if (direction === 'DOWN') headAngle = Math.PI / 2;
    else if (direction === 'LEFT') headAngle = Math.PI;
    else if (direction === 'UP') headAngle = -Math.PI / 2;

    // Check distance to nearest food for reactive jaw-lunge animation!
    let minFoodDist = 999;
    for (let f = 0; f < foods.length; f++) {
      const fx = (foods[f].x + 0.5) * cellSize;
      const fy = (foods[f].y + 0.5) * cellSize;
      const d = Math.hypot(fx - headPt.x, fy - headPt.y) / cellSize;
      if (d < minFoodDist) minFoodDist = d;
    }
    const jawOpen = minFoodDist < 2.6 ? Math.max(0, (2.6 - minFoodDist) / 2.6) : 0;

    ctx.save();
    ctx.translate(headPt.x, headPt.y);
    ctx.rotate(headAngle);

    // Head glow
    ctx.shadowColor = isBoosting ? '#00E5FF' : '#00FF66';
    ctx.shadowBlur = isBoosting ? 20 : 14;

    const r = cellSize * (0.48 + jawOpen * 0.08);

    // If jaw is opening near food, draw glowing green energy mandibles
    if (jawOpen > 0.05) {
      ctx.strokeStyle = '#00FF66';
      ctx.lineWidth = 2.2;
      const spread = jawOpen * cellSize * 0.24;
      ctx.beginPath();
      // Left mandible
      ctx.moveTo(r * 0.2, -r * 0.55);
      ctx.lineTo(r * 1.15, -r * 0.45 - spread);
      // Right mandible
      ctx.moveTo(r * 0.2, r * 0.55);
      ctx.lineTo(r * 1.15, r * 0.45 + spread);
      ctx.stroke();
    }

    // Angular Geometric Viper Head Chassis (#F8FAFC Crisp Phosphor White)
    ctx.fillStyle = '#F8FAFC';
    ctx.beginPath();
    ctx.moveTo(r * 1.05, 0); // Snout tip
    ctx.lineTo(r * 0.35, -r * 0.85);
    ctx.lineTo(-r * 0.75, -r * 0.72);
    ctx.lineTo(-r * 0.9, 0);
    ctx.lineTo(-r * 0.75, r * 0.72);
    ctx.lineTo(r * 0.35, r * 0.85);
    ctx.closePath();
    ctx.fill();

    // Tactical visor / cybernetic eyes
    ctx.fillStyle = '#08090D';
    ctx.beginPath();
    ctx.arc(r * 0.22, -r * 0.36, r * 0.2, 0, Math.PI * 2);
    ctx.arc(r * 0.22, r * 0.36, r * 0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = jawOpen > 0.2 ? '#00FF66' : '#00E5FF';
    ctx.beginPath();
    ctx.arc(r * 0.26, -r * 0.36, r * 0.11, 0, Math.PI * 2);
    ctx.arc(r * 0.26, r * 0.36, r * 0.11, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // 6. Render Object-Pooled Particles
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    if (!p.active) continue;

    const alpha = Math.max(0, (p.life / p.maxLife) * p.alpha);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rotation);
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.shadowBlur = 8;

    if (p.shape === 'SPARK') {
      ctx.fillRect(-p.size * 1.6, -p.size * 0.35, p.size * 3.2, p.size * 0.7);
    } else if (p.shape === 'DIAMOND') {
      ctx.rotate(Math.PI / 4);
      ctx.fillRect(-p.size * 0.5, -p.size * 0.5, p.size, p.size);
    } else {
      ctx.fillRect(-p.size * 0.5, -p.size * 0.5, p.size, p.size);
    }
    ctx.restore();
  }

  // 7. Render Floating Telemetry / Score Popups
  for (let i = 0; i < floatingTexts.length; i++) {
    const ft = floatingTexts[i];
    if (!ft.active) continue;
    const progress = 1 - ft.life / ft.maxLife;
    const alpha = progress < 0.7 ? 1 : 1 - (progress - 0.7) / 0.3;

    ctx.save();
    ctx.globalAlpha = Math.max(0, alpha);
    ctx.translate(ft.x, ft.y);
    const popScale = progress < 0.15 ? 0.7 + (progress / 0.15) * 0.45 : 1.05;
    ctx.scale(ft.scale * popScale, ft.scale * popScale);

    ctx.font = '800 14px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.shadowColor = ft.color;
    ctx.shadowBlur = 10;
    ctx.fillStyle = ft.color;
    ctx.fillText(ft.text, 0, 0);

    if (ft.subtext) {
      ctx.font = '700 10px "JetBrains Mono", monospace';
      ctx.fillStyle = '#F8FAFC';
      ctx.fillText(ft.subtext, 0, 13);
    }
    ctx.restore();
  }

  // 8. Arena Perimeter Frame & Reactive Status Border
  let borderColor = '#1E2436';
  let borderGlow = 0;

  if (dangerPulse > 0.05) {
    borderColor = lerpColor('#1E2436', '#FF2A5F', dangerPulse);
    borderGlow = dangerPulse * 18;
  } else if (borderPulse > 0.05) {
    borderColor = lerpColor('#1E2436', '#00FF66', borderPulse);
    borderGlow = borderPulse * 16;
  } else if (currentChain >= 4) {
    borderColor = 'rgba(255, 184, 0, 0.55)';
    borderGlow = 8;
  }

  ctx.save();
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = 3;
  if (borderGlow > 0) {
    ctx.shadowColor = borderColor;
    ctx.shadowBlur = borderGlow;
  }
  ctx.strokeRect(1.5, 1.5, width - 3, height - 3);

  // Corner tactical bracket accents
  const cornerLen = Math.max(12, cellSize * 0.85);
  ctx.strokeStyle = dangerPulse > 0.2 ? '#FF2A5F' : '#00FF66';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  // Top-left
  ctx.moveTo(2, cornerLen);
  ctx.lineTo(2, 2);
  ctx.lineTo(cornerLen, 2);
  // Top-right
  ctx.moveTo(width - cornerLen, 2);
  ctx.lineTo(width - 2, 2);
  ctx.lineTo(width - 2, cornerLen);
  // Bottom-left
  ctx.moveTo(2, height - cornerLen);
  ctx.lineTo(2, height - 2);
  ctx.lineTo(cornerLen, height - 2);
  // Bottom-right
  ctx.moveTo(width - cornerLen, height - 2);
  ctx.lineTo(width - 2, height - 2);
  ctx.lineTo(width - 2, height - cornerLen);
  ctx.stroke();
  ctx.restore();

  ctx.restore();
}
