import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Direction,
  FloatingText,
  FoodItem,
  GameState,
  GridPoint,
  GridShockwave,
  HighScoreEntry,
  Particle,
  RunStats,
  SpeedPreset,
} from './types/game';
import { renderGameCanvas } from './utils/canvasRenderer';
import { sound } from './utils/sound';
import {
  getLeaderboard,
  getSavedInitials,
  insertHighScore,
  qualifiesForLeaderboard,
  resetLeaderboardToDefault,
  updateHighScoreInitials,
} from './utils/storage';
import { TopHudBar } from './components/TopHudBar';
import { StartOverlay } from './components/StartOverlay';
import { PauseOverlay } from './components/PauseOverlay';
import { GameOverOverlay } from './components/GameOverOverlay';
import { TouchControlDock } from './components/TouchControlDock';

const GRID_SIZE = 24;
const MAX_PARTICLES = 160;
const MAX_FLOATING_TEXTS = 24;
const MAX_SHOCKWAVES = 10;
const CHAIN_DECAY_SECONDS = 3.8;

const BASE_SPEED_BY_PRESET: Record<SpeedPreset, number> = {
  ARCADE: 8.5, // cells per second at 1.0x
  TURBO: 11.0,
  HYPER: 13.5,
};

const SCORE_MULT_BY_PRESET: Record<SpeedPreset, number> = {
  ARCADE: 1.0,
  TURBO: 1.3,
  HYPER: 1.6,
};

function isOppositeDirection(a: Direction, b: Direction): boolean {
  if (a === 'UP' && b === 'DOWN') return true;
  if (a === 'DOWN' && b === 'UP') return true;
  if (a === 'LEFT' && b === 'RIGHT') return true;
  if (a === 'RIGHT' && b === 'LEFT') return true;
  return false;
}

function getDirectionDelta(dir: Direction): GridPoint {
  switch (dir) {
    case 'UP':
      return { x: 0, y: -1 };
    case 'DOWN':
      return { x: 0, y: 1 };
    case 'LEFT':
      return { x: -1, y: 0 };
    case 'RIGHT':
      return { x: 1, y: 0 };
  }
}

export function App() {
  // React UI state synced cleanly with simulation engine
  const [gameState, setGameState] = useState<GameState>('START');
  const [preset, setPreset] = useState<SpeedPreset>('ARCADE');
  const [isMuted, setIsMuted] = useState<boolean>(() => sound.isMuted());
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 640;
    }
    return false;
  });

  const [leaderboard, setLeaderboard] = useState<HighScoreEntry[]>(() => getLeaderboard());
  const [newRecordId, setNewRecordId] = useState<string | null>(null);
  const [newRecordRank, setNewRecordRank] = useState<number | null>(null);
  const [deathReason, setDeathReason] = useState<string>('');
  const [activeDirection, setActiveDirection] = useState<Direction>('RIGHT');

  const [stats, setStats] = useState<RunStats>({
    score: 0,
    foodEaten: 0,
    maxChain: 1,
    currentChain: 1,
    chainTimer: 0,
    length: 4,
    speedMultiplier: 1.0,
    isBoosting: false,
    closeCalls: 0,
    durationSec: 0,
  });

  // Canvas & layout refs
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [arenaSizePx, setArenaSizePx] = useState<number>(560);

  // Mutable high-frequency simulation state inside ref for 60fps zero-lag loop
  const simRef = useRef<{
    gameState: GameState;
    preset: SpeedPreset;
    segments: GridPoint[];
    prevSegments: GridPoint[];
    direction: Direction;
    inputQueue: Direction[];
    moveProgress: number;
    pendingGrowth: number;
    foods: FoodItem[];
    nextFoodId: number;
    score: number;
    foodEaten: number;
    primaryFoodCount: number;
    currentChain: number;
    maxChain: number;
    chainTimer: number; // 0..1
    speedMultiplier: number;
    isBoosting: boolean;
    closeCalls: number;
    lastSkimBonusCell: string;
    runStartTime: number;
    hitStopTimer: number;
    dyingTimer: number;
    shakeTrauma: number;
    shakeDirX: number;
    shakeDirY: number;
    borderPulse: number;
    dangerPulse: number;
    digestPulses: number[];
    particles: Particle[];
    floatingTexts: FloatingText[];
    shockwaves: GridShockwave[];
    swipeStartX: number | null;
    swipeStartY: number | null;
  }>({
    gameState: 'START',
    preset: 'ARCADE',
    segments: [],
    prevSegments: [],
    direction: 'RIGHT',
    inputQueue: [],
    moveProgress: 0,
    pendingGrowth: 0,
    foods: [],
    nextFoodId: 1,
    score: 0,
    foodEaten: 0,
    primaryFoodCount: 0,
    currentChain: 1,
    maxChain: 1,
    chainTimer: 0,
    speedMultiplier: 1.0,
    isBoosting: false,
    closeCalls: 0,
    lastSkimBonusCell: '',
    runStartTime: 0,
    hitStopTimer: 0,
    dyingTimer: 0,
    shakeTrauma: 0,
    shakeDirX: 0,
    shakeDirY: 0,
    borderPulse: 0,
    dangerPulse: 0,
    digestPulses: [],
    particles: Array.from({ length: MAX_PARTICLES }, () => ({
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      size: 4,
      color: '#00FF66',
      alpha: 1,
      life: 0,
      maxLife: 1,
      shape: 'SQUARE',
      rotation: 0,
      vRot: 0,
    })),
    floatingTexts: Array.from({ length: MAX_FLOATING_TEXTS }, () => ({
      active: false,
      x: 0,
      y: 0,
      vy: -30,
      text: '',
      color: '#00FF66',
      life: 0,
      maxLife: 1,
      scale: 1,
    })),
    shockwaves: Array.from({ length: MAX_SHOCKWAVES }, () => ({
      active: false,
      x: 0,
      y: 0,
      radius: 0,
      maxRadius: 6,
      color: '#00FF66',
      life: 0,
      maxLife: 0.45,
    })),
    swipeStartX: null,
    swipeStartY: null,
  });

  // Helper: Spawn Particle from Object Pool
  const spawnParticle = useCallback(
    (
      x: number,
      y: number,
      vx: number,
      vy: number,
      color: string,
      size: number,
      maxLife: number,
      shape: 'SQUARE' | 'DIAMOND' | 'SPARK' = 'SQUARE'
    ) => {
      const pool = simRef.current.particles;
      for (let i = 0; i < pool.length; i++) {
        if (!pool[i].active) {
          const p = pool[i];
          p.active = true;
          p.x = x;
          p.y = y;
          p.vx = vx;
          p.vy = vy;
          p.color = color;
          p.size = size;
          p.alpha = 1;
          p.life = maxLife;
          p.maxLife = maxLife;
          p.shape = shape;
          p.rotation = Math.atan2(vy, vx);
          p.vRot = (Math.random() - 0.5) * 10;
          return;
        }
      }
    },
    []
  );

  // Helper: Spawn Floating Score Popup from Pool
  const spawnFloatingText = useCallback(
    (
      x: number,
      y: number,
      text: string,
      color: string = '#00FF66',
      subtext?: string,
      scale: number = 1
    ) => {
      const pool = simRef.current.floatingTexts;
      for (let i = 0; i < pool.length; i++) {
        if (!pool[i].active) {
          const ft = pool[i];
          ft.active = true;
          ft.x = x;
          ft.y = y;
          ft.vy = -42;
          ft.text = text;
          ft.subtext = subtext;
          ft.color = color;
          ft.life = 0.78;
          ft.maxLife = 0.78;
          ft.scale = scale;
          return;
        }
      }
    },
    []
  );

  // Helper: Spawn Grid Shockwave Ring from Pool
  const spawnShockwave = useCallback(
    (gx: number, gy: number, color: string = '#00FF66', maxRadius: number = 6.5) => {
      const pool = simRef.current.shockwaves;
      for (let i = 0; i < pool.length; i++) {
        if (!pool[i].active) {
          const sw = pool[i];
          sw.active = true;
          sw.x = gx;
          sw.y = gy;
          sw.radius = 0.35;
          sw.maxRadius = maxRadius;
          sw.color = color;
          sw.life = 0.45;
          sw.maxLife = 0.45;
          return;
        }
      }
    },
    []
  );

  // Helper: Find unoccupied grid coordinate for food
  const findFreeCell = useCallback((preferNearCenter: boolean = false): GridPoint => {
    const sim = simRef.current;
    const occupied = new Set<string>();
    for (const seg of sim.segments) {
      occupied.add(`${seg.x},${seg.y}`);
    }
    for (const f of sim.foods) {
      occupied.add(`${f.x},${f.y}`);
    }

    const candidates: GridPoint[] = [];
    const margin = preferNearCenter ? 2 : 1;
    for (let x = margin; x < GRID_SIZE - margin; x++) {
      for (let y = margin; y < GRID_SIZE - margin; y++) {
        if (!occupied.has(`${x},${y}`)) {
          // Avoid spawning directly 1 tile in front of the snake head
          if (sim.segments.length > 0) {
            const head = sim.segments[0];
            if (Math.abs(head.x - x) + Math.abs(head.y - y) <= 1) continue;
          }
          candidates.push({ x, y });
        }
      }
    }

    if (candidates.length === 0) {
      // Fallback to any free cell on the board
      for (let x = 0; x < GRID_SIZE; x++) {
        for (let y = 0; y < GRID_SIZE; y++) {
          if (!occupied.has(`${x},${y}`)) {
            candidates.push({ x, y });
          }
        }
      }
    }

    if (candidates.length === 0) return { x: 12, y: 12 };
    return candidates[Math.floor(Math.random() * candidates.length)];
  }, []);

  // Spawn Primary Radioactive Green Food
  const spawnPrimaryGreenFood = useCallback(
    (nearHeadForFastStart: boolean = false) => {
      const sim = simRef.current;
      let pos: GridPoint;

      if (nearHeadForFastStart && sim.segments.length > 0) {
        // Place the very first green food 5 cells ahead of the snake so the player gets their first juicy bite within 1.2 seconds!
        const head = sim.segments[0];
        pos = {
          x: Math.min(GRID_SIZE - 3, head.x + 5),
          y: head.y,
        };
      } else {
        pos = findFreeCell(false);
      }

      sim.foods.push({
        id: sim.nextFoodId++,
        x: pos.x,
        y: pos.y,
        type: 'PRIMARY_GREEN',
        spawnTime: performance.now(),
        expiresAt: null,
        value: 100,
        pulsePhase: Math.random() * Math.PI * 2,
      });
    },
    [findFreeCell]
  );

  // Spawn a Cluster Wave of 3 bonus green energy orbs
  const spawnClusterWave = useCallback(() => {
    const sim = simRef.current;
    const now = performance.now();
    for (let i = 0; i < 3; i++) {
      const pos = findFreeCell(true);
      sim.foods.push({
        id: sim.nextFoodId++,
        x: pos.x,
        y: pos.y,
        type: 'CLUSTER_GREEN',
        spawnTime: now,
        expiresAt: now + 6500,
        value: 150,
        pulsePhase: i * 1.2,
      });
      spawnShockwave(pos.x, pos.y, '#00E5FF', 3.5);
    }
    sound.playClusterSpawn();
  }, [findFreeCell, spawnShockwave]);

  // Reset / Initialize Snake Arena State
  const initArena = useCallback(
    (targetState: GameState, selectedPreset?: SpeedPreset) => {
      const sim = simRef.current;
      const activePreset = selectedPreset || sim.preset;
      sim.preset = activePreset;
      sim.gameState = targetState;

      const startX = 7;
      const startY = Math.floor(GRID_SIZE / 2);
      const initialSegments: GridPoint[] = [
        { x: startX, y: startY },
        { x: startX - 1, y: startY },
        { x: startX - 2, y: startY },
        { x: startX - 3, y: startY },
      ];

      sim.segments = initialSegments.map((p) => ({ ...p }));
      sim.prevSegments = initialSegments.map((p) => ({ ...p }));
      sim.direction = 'RIGHT';
      sim.inputQueue = [];
      sim.moveProgress = 0;
      sim.pendingGrowth = 0;
      sim.foods = [];
      sim.score = 0;
      sim.foodEaten = 0;
      sim.primaryFoodCount = 0;
      sim.currentChain = 1;
      sim.maxChain = 1;
      sim.chainTimer = 0;
      sim.speedMultiplier = 1.0;
      sim.isBoosting = false;
      sim.closeCalls = 0;
      sim.lastSkimBonusCell = '';
      sim.runStartTime = performance.now();
      sim.hitStopTimer = 0;
      sim.dyingTimer = 0;
      sim.shakeTrauma = 0;
      sim.borderPulse = 0;
      sim.dangerPulse = 0;
      sim.digestPulses = [];

      // Clear active floating texts
      for (const ft of sim.floatingTexts) ft.active = false;
      for (const sw of sim.shockwaves) sw.active = false;

      // Spawn the first green food right in front of the snake so the first 3 seconds are immediately rewarding!
      spawnPrimaryGreenFood(true);

      setGameState(targetState);
      setActiveDirection('RIGHT');
      setNewRecordId(null);
      setNewRecordRank(null);
      setDeathReason('');
      setStats({
        score: 0,
        foodEaten: 0,
        maxChain: 1,
        currentChain: 1,
        chainTimer: 0,
        length: 4,
        speedMultiplier: 1.0,
        isBoosting: false,
        closeCalls: 0,
        durationSec: 0,
      });
    },
    [spawnPrimaryGreenFood]
  );

  // Queue directional input with strict 2-step turn buffer
  const queueDirectionInput = useCallback((newDir: Direction) => {
    const sim = simRef.current;
    if (sim.gameState !== 'PLAYING') return;

    // Determine effective last direction (either last item in queue or current active direction)
    const lastScheduledDir =
      sim.inputQueue.length > 0
        ? sim.inputQueue[sim.inputQueue.length - 1]
        : sim.direction;

    // Ignore duplicate or 180-degree opposite turns
    if (newDir === lastScheduledDir || isOppositeDirection(newDir, lastScheduledDir)) {
      return;
    }

    if (sim.inputQueue.length < 2) {
      sim.inputQueue.push(newDir);
      sound.playTurn();
    }
  }, []);

  // AI Pathfinder for Start Screen Attract Mode
  const computeAttractModeTurn = useCallback((): Direction => {
    const sim = simRef.current;
    const head = sim.segments[0];
    if (!head) return sim.direction;

    const target = sim.foods[0] || { x: 12, y: 12 };
    const allDirs: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
    const possibleDirs: Direction[] = allDirs.filter(
      (d) => !isOppositeDirection(d, sim.direction)
    );

    const occupied = new Set<string>();
    for (let i = 0; i < sim.segments.length - 1; i++) {
      occupied.add(`${sim.segments[i].x},${sim.segments[i].y}`);
    }

    let bestDir = sim.direction;
    let bestScore = -99999;

    for (const dir of possibleDirs) {
      const delta = getDirectionDelta(dir);
      const nx = head.x + delta.x;
      const ny = head.y + delta.y;

      // Check wall or body collision
      if (nx < 0 || nx >= GRID_SIZE || ny < 0 || ny >= GRID_SIZE) continue;
      if (occupied.has(`${nx},${ny}`)) continue;

      // Count open neighbor cells around (nx, ny) so AI avoids dead-ends
      let openNeighbors = 0;
      for (const nd of ['UP', 'DOWN', 'LEFT', 'RIGHT'] as Direction[]) {
        const d2 = getDirectionDelta(nd);
        const nnx = nx + d2.x;
        const nny = ny + d2.y;
        if (
          nnx >= 0 &&
          nnx < GRID_SIZE &&
          nny >= 0 &&
          nny < GRID_SIZE &&
          !occupied.has(`${nnx},${nny}`)
        ) {
          openNeighbors++;
        }
      }

      const distToFood = Math.abs(target.x - nx) + Math.abs(target.y - ny);
      const score = -distToFood * 10 + openNeighbors * 6 + (dir === sim.direction ? 1 : 0);
      if (score > bestScore) {
        bestScore = score;
        bestDir = dir;
      }
    }

    return bestDir;
  }, []);

  // Responsive Viewport Sizing for Square Arena
  useEffect(() => {
    const updateSize = () => {
      if (!containerRef.current) return;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      // Reserve space for TopHudBar (~64px) and TouchControlDock if active (~126px)
      const reservedVertical = showTouchControls ? 204 : 88;
      const maxW = Math.min(vw - 16, 660);
      const maxH = Math.min(vh - reservedVertical, 660);
      const size = Math.max(260, Math.floor(Math.min(maxW, maxH)));
      setArenaSizePx(size);
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, [showTouchControls]);

  // Initialize Attract Mode on mount
  useEffect(() => {
    initArena('START', 'ARCADE');
  }, [initArena]);

  // Keyboard Controls Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Do not intercept keys if user is typing their 3-letter callsign in an input
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;

      const sim = simRef.current;
      const key = e.key.toLowerCase();

      // Audio mute shortcut
      if (key === 'm') {
        e.preventDefault();
        const muted = sound.toggleMute();
        setIsMuted(muted);
        return;
      }

      // Start or Game Over -> Space / Enter launches run immediately
      if (sim.gameState === 'START' || sim.gameState === 'GAMEOVER') {
        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          sound.playButton();
          initArena('PLAYING', sim.preset);
          return;
        }
      }

      // Pause / Resume shortcuts
      if (key === 'p' || e.key === 'Escape') {
        if (sim.gameState === 'PLAYING') {
          e.preventDefault();
          sound.playButton();
          sim.gameState = 'PAUSED';
          sim.isBoosting = false;
          setGameState('PAUSED');
          return;
        } else if (sim.gameState === 'PAUSED') {
          e.preventDefault();
          sound.playButton();
          sim.gameState = 'PLAYING';
          setGameState('PLAYING');
          return;
        }
      }

      if (sim.gameState === 'PAUSED' && e.key === ' ') {
        e.preventDefault();
        sound.playButton();
        sim.gameState = 'PLAYING';
        setGameState('PLAYING');
        return;
      }

      // Instant Restart shortcut (R)
      if (key === 'r' && (sim.gameState === 'PLAYING' || sim.gameState === 'PAUSED' || sim.gameState === 'GAMEOVER')) {
        e.preventDefault();
        sound.playButton();
        initArena('PLAYING', sim.preset);
        return;
      }

      // Overdrive Boost (Shift or Space during active play)
      if (sim.gameState === 'PLAYING' && (e.key === 'Shift' || e.key === ' ')) {
        e.preventDefault();
        sim.isBoosting = true;
      }

      // Directional Controls (WASD + Arrow Keys)
      if (e.key === 'ArrowUp' || key === 'w') {
        e.preventDefault();
        queueDirectionInput('UP');
      } else if (e.key === 'ArrowDown' || key === 's') {
        e.preventDefault();
        queueDirectionInput('DOWN');
      } else if (e.key === 'ArrowLeft' || key === 'a') {
        e.preventDefault();
        queueDirectionInput('LEFT');
      } else if (e.key === 'ArrowRight' || key === 'd') {
        e.preventDefault();
        queueDirectionInput('RIGHT');
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Shift' || e.key === ' ') {
        simRef.current.isBoosting = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [initArena, queueDirectionInput]);

  // Main 60fps requestAnimationFrame Simulation & Render Loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();
    let uiSyncAccumulator = 0;

    const stepSimulation = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      // Clamp dt to prevent huge jumps if tab was backgrounded
      const dt = Math.min(rawDt, 0.085);

      const sim = simRef.current;
      const canvas = canvasRef.current;
      if (!canvas) {
        animationFrameId = requestAnimationFrame(stepSimulation);
        return;
      }

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetPixelSize = Math.round(arenaSizePx * dpr);
      if (canvas.width !== targetPixelSize || canvas.height !== targetPixelSize) {
        canvas.width = targetPixelSize;
        canvas.height = targetPixelSize;
      }

      const cellSize = canvas.width / GRID_SIZE;

      // 1. Update visual pulses & camera trauma decay
      sim.borderPulse = Math.max(0, sim.borderPulse - dt * 3.2);
      sim.dangerPulse = Math.max(0, sim.dangerPulse - dt * 2.5);
      sim.shakeTrauma = Math.max(0, sim.shakeTrauma - dt * 34);

      // Update digestive energy waves travelling head -> tail
      for (let i = sim.digestPulses.length - 1; i >= 0; i--) {
        sim.digestPulses[i] += dt * 2.6;
        if (sim.digestPulses[i] >= 1) {
          sim.digestPulses.splice(i, 1);
        }
      }

      // Update object-pooled particles
      for (let i = 0; i < sim.particles.length; i++) {
        const p = sim.particles[i];
        if (!p.active) continue;
        p.life -= dt;
        if (p.life <= 0) {
          p.active = false;
          continue;
        }
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        // Drag
        p.vx *= Math.pow(0.06, dt);
        p.vy *= Math.pow(0.06, dt);
        p.rotation += p.vRot * dt;

        // Bounce off arena walls
        if (p.x < 4 || p.x > canvas.width - 4) p.vx *= -0.75;
        if (p.y < 4 || p.y > canvas.height - 4) p.vy *= -0.75;
      }

      // Update floating texts
      for (let i = 0; i < sim.floatingTexts.length; i++) {
        const ft = sim.floatingTexts[i];
        if (!ft.active) continue;
        ft.life -= dt;
        if (ft.life <= 0) {
          ft.active = false;
          continue;
        }
        ft.y += ft.vy * dt;
        ft.vy *= Math.pow(0.25, dt);
      }

      // Update grid shockwaves
      for (let i = 0; i < sim.shockwaves.length; i++) {
        const sw = sim.shockwaves[i];
        if (!sw.active) continue;
        sw.life -= dt;
        if (sw.life <= 0) {
          sw.active = false;
          continue;
        }
        const progress = 1 - sw.life / sw.maxLife;
        sw.radius = 0.35 + progress * sw.maxRadius;
      }

      // Remove expired bonus cluster orbs
      for (let i = sim.foods.length - 1; i >= 0; i--) {
        const f = sim.foods[i];
        if (f.expiresAt !== null && now >= f.expiresAt) {
          sim.foods.splice(i, 1);
        }
      }

      // Ensure there is ALWAYS at least one PRIMARY_GREEN food on the arena
      if (!sim.foods.some((f) => f.type === 'PRIMARY_GREEN')) {
        spawnPrimaryGreenFood(false);
      }

      // Handle DYING slow-mo shatter transition to GAMEOVER
      if (sim.gameState === 'DYING') {
        sim.dyingTimer -= dt;
        if (sim.dyingTimer <= 0) {
          sim.gameState = 'GAMEOVER';
          setGameState('GAMEOVER');
        }
      }

      // 2. Step Snake Simulation when in PLAYING or START (AI Demo Attract) state
      if (sim.gameState === 'PLAYING' || sim.gameState === 'START') {
        // Decay combo chain timer in PLAYING state
        if (sim.gameState === 'PLAYING' && sim.chainTimer > 0) {
          sim.chainTimer = Math.max(0, sim.chainTimer - dt / CHAIN_DECAY_SECONDS);
          if (sim.chainTimer === 0 && sim.currentChain > 1) {
            sim.currentChain = 1;
          }
        }

        // Hit-stop micro-freeze for impact punch on food pickup
        if (sim.hitStopTimer > 0) {
          sim.hitStopTimer = Math.max(0, sim.hitStopTimer - dt);
        } else {
          const baseCps = BASE_SPEED_BY_PRESET[sim.preset];
          const boostFactor = sim.isBoosting ? 1.65 : 1.0;
          const effectiveCps = baseCps * sim.speedMultiplier * boostFactor;

          // Emit subtle thruster particles when boosting
          if (sim.isBoosting && sim.segments.length > 0 && Math.random() < 0.65) {
            const head = sim.segments[0];
            const hx = (head.x + 0.5) * cellSize;
            const hy = (head.y + 0.5) * cellSize;
            spawnParticle(
              hx + (Math.random() - 0.5) * cellSize * 0.4,
              hy + (Math.random() - 0.5) * cellSize * 0.4,
              (Math.random() - 0.5) * 90,
              (Math.random() - 0.5) * 90,
              '#00E5FF',
              Math.max(3, cellSize * 0.14),
              0.24,
              'DIAMOND'
            );
          }

          sim.moveProgress += dt * effectiveCps;

          while (sim.moveProgress >= 1.0) {
            sim.moveProgress -= 1.0;

            // Determine next direction
            if (sim.gameState === 'START') {
              sim.direction = computeAttractModeTurn();
            } else if (sim.inputQueue.length > 0) {
              const nextDir = sim.inputQueue.shift()!;
              if (!isOppositeDirection(nextDir, sim.direction)) {
                sim.direction = nextDir;
                setActiveDirection(nextDir);
              }
            }

            const delta = getDirectionDelta(sim.direction);
            const currentHead = sim.segments[0];
            const nextHead: GridPoint = {
              x: currentHead.x + delta.x,
              y: currentHead.y + delta.y,
            };

            // Check Wall Collision
            const hitWall =
              nextHead.x < 0 ||
              nextHead.x >= GRID_SIZE ||
              nextHead.y < 0 ||
              nextHead.y >= GRID_SIZE;

            // Check Self Collision (exclude last tail cell if not growing)
            const checkLen =
              sim.pendingGrowth > 0 ? sim.segments.length : sim.segments.length - 1;
            let hitSelf = false;
            for (let i = 0; i < checkLen; i++) {
              if (sim.segments[i].x === nextHead.x && sim.segments[i].y === nextHead.y) {
                hitSelf = true;
                break;
              }
            }

            if (hitWall || hitSelf) {
              if (sim.gameState === 'START') {
                // Attract mode AI simply resets cleanly
                initArena('START', sim.preset);
                break;
              } else {
                // Trigger Juicy Death Sequence!
                sound.playCrash();
                sim.isBoosting = false;
                sim.shakeTrauma = 14;
                sim.shakeDirX = delta.x;
                sim.shakeDirY = delta.y;
                sim.dangerPulse = 1.0;
                sim.dyingTimer = 0.44;
                sim.gameState = 'DYING';
                setGameState('DYING');
                setDeathReason(hitWall ? 'PERIMETER WALL IMPACT' : 'SELF-TAIL COLLISION');

                // Shatter snake segments into glowing crimson & cyan particles
                for (let s = 0; s < sim.segments.length; s++) {
                  const seg = sim.segments[s];
                  const sx = (seg.x + 0.5) * cellSize;
                  const sy = (seg.y + 0.5) * cellSize;
                  const count = s === 0 ? 18 : 4;
                  for (let k = 0; k < count; k++) {
                    const angle = Math.random() * Math.PI * 2;
                    const speed = (60 + Math.random() * 240) * (canvas.width / 560);
                    spawnParticle(
                      sx,
                      sy,
                      Math.cos(angle) * speed,
                      Math.sin(angle) * speed,
                      s === 0 || k % 2 === 0 ? '#FF2A5F' : '#00E5FF',
                      Math.max(4, cellSize * (s === 0 ? 0.28 : 0.2)),
                      0.45 + Math.random() * 0.3,
                      k % 2 === 0 ? 'SPARK' : 'DIAMOND'
                    );
                  }
                }

                // Check & Persist High Score to LocalStorage
                const finalScore = sim.score;
                if (qualifiesForLeaderboard(finalScore)) {
                  const savedInit = getSavedInitials();
                  const { board, insertedId, rank } = insertHighScore({
                    initials: savedInit,
                    score: finalScore,
                    maxChain: sim.maxChain,
                    maxLength: sim.segments.length,
                    peakSpeed: Number(sim.speedMultiplier.toFixed(1)),
                    preset: sim.preset,
                  });
                  setLeaderboard(board);
                  setNewRecordId(insertedId);
                  setNewRecordRank(rank);
                  setTimeout(() => sound.playNewHighScore(), 180);
                } else {
                  setLeaderboard(getLeaderboard());
                  setNewRecordId(null);
                  setNewRecordRank(null);
                }

                // Sync final stats
                setStats({
                  score: sim.score,
                  foodEaten: sim.foodEaten,
                  maxChain: sim.maxChain,
                  currentChain: sim.currentChain,
                  chainTimer: 0,
                  length: sim.segments.length,
                  speedMultiplier: sim.speedMultiplier,
                  isBoosting: false,
                  closeCalls: sim.closeCalls,
                  durationSec: Math.round((now - sim.runStartTime) / 1000),
                });
                break;
              }
            }

            // Advance Snake Segments on Grid
            if (sim.pendingGrowth > 0) {
              sim.prevSegments = [
                ...sim.segments.map((p) => ({ ...p })),
                { ...sim.segments[sim.segments.length - 1] },
              ];
              sim.segments.unshift(nextHead);
              sim.pendingGrowth--;
            } else {
              sim.prevSegments = sim.segments.map((p) => ({ ...p }));
              sim.segments.unshift(nextHead);
              sim.segments.pop();
            }

            // Check Wall-Skim / Close-Call Bonus (when turning parallel right along the outer boundary wall)
            if (sim.gameState === 'PLAYING' && sim.speedMultiplier >= 1.2) {
              const onPerimeter =
                nextHead.x === 0 ||
                nextHead.x === GRID_SIZE - 1 ||
                nextHead.y === 0 ||
                nextHead.y === GRID_SIZE - 1;
              const cellKey = `${nextHead.x},${nextHead.y}`;
              if (onPerimeter && sim.lastSkimBonusCell !== cellKey && Math.random() < 0.25) {
                sim.lastSkimBonusCell = cellKey;
                sim.closeCalls++;
                const skimPts = 25 * sim.currentChain;
                sim.score += skimPts;
                sound.playCloseCall();
                const px = (nextHead.x + 0.5) * cellSize;
                const py = (nextHead.y + 0.5) * cellSize;
                spawnFloatingText(
                  px,
                  Math.max(28, Math.min(canvas.height - 28, py)),
                  `WALL SKIM +${skimPts}`,
                  '#00E5FF',
                  undefined,
                  0.85
                );
                for (let k = 0; k < 5; k++) {
                  spawnParticle(
                    px,
                    py,
                    (Math.random() - 0.5) * 140,
                    (Math.random() - 0.5) * 140,
                    '#00E5FF',
                    cellSize * 0.16,
                    0.25,
                    'SPARK'
                  );
                }
              }
            }

            // Check Food Consumption
            const eatenIndex = sim.foods.findIndex(
              (f) => f.x === nextHead.x && f.y === nextHead.y
            );
            if (eatenIndex !== -1) {
              const eatenFood = sim.foods[eatenIndex];
              sim.foods.splice(eatenIndex, 1);

              // Grow snake longer!
              sim.pendingGrowth += 1;
              sim.foodEaten += 1;

              // Update Chain Multiplier
              if (sim.chainTimer > 0) {
                sim.currentChain = Math.min(16, sim.currentChain + 1);
              } else {
                sim.currentChain = 1;
              }
              sim.maxChain = Math.max(sim.maxChain, sim.currentChain);
              sim.chainTimer = 1.0;

              // Calculate Points
              const presetMult = SCORE_MULT_BY_PRESET[sim.preset];
              const boostBonus = sim.isBoosting ? 1.5 : 1.0;
              const pointsEarned = Math.round(
                eatenFood.value * sim.currentChain * presetMult * boostBonus
              );
              if (sim.gameState === 'PLAYING') {
                sim.score += pointsEarned;
              }

              // Ramp velocity smoothly (asymptotic curve up to 2.6x)
              sim.speedMultiplier = Number(
                Math.min(2.6, 1.0 + sim.foodEaten * 0.045).toFixed(2)
              );

              // Trigger Juicy Feedback: Hit-stop, Directional Shake, Digestive Pulse, Grid Shockwave, Particle Burst!
              sim.hitStopTimer = 0.022;
              sim.shakeTrauma = Math.min(8.5, 3.2 + sim.currentChain * 0.45);
              sim.shakeDirX = delta.x;
              sim.shakeDirY = delta.y;
              sim.borderPulse = 1.0;
              sim.digestPulses.push(0);

              if (sim.gameState === 'PLAYING') {
                sound.playEat(sim.currentChain, eatenFood.type === 'CLUSTER_GREEN');
              }

              const fx = (eatenFood.x + 0.5) * cellSize;
              const fy = (eatenFood.y + 0.5) * cellSize;

              // Particle Explosion
              const particleCount = 22;
              for (let p = 0; p < particleCount; p++) {
                const angle = (Math.PI * 2 * p) / particleCount + (Math.random() - 0.5) * 0.35;
                const speed = (80 + Math.random() * 240) * (canvas.width / 560);
                const colors = ['#00FF66', '#CCFFDF', '#00E5FF', '#FFB800'];
                const color =
                  p % 5 === 0 && sim.currentChain >= 3
                    ? '#FFB800'
                    : colors[p % 3];
                spawnParticle(
                  fx,
                  fy,
                  Math.cos(angle) * speed,
                  Math.sin(angle) * speed,
                  color,
                  Math.max(3.5, cellSize * (0.16 + Math.random() * 0.14)),
                  0.32 + Math.random() * 0.25,
                  p % 2 === 0 ? 'SPARK' : 'DIAMOND'
                );
              }

              // Radial Grid Shockwave
              spawnShockwave(
                eatenFood.x,
                eatenFood.y,
                sim.currentChain >= 5 ? '#FFB800' : '#00FF66',
                5.5 + Math.min(4, sim.currentChain * 0.35)
              );

              // Floating Score Popup
              if (sim.gameState === 'PLAYING') {
                const clampedY = Math.max(32, Math.min(canvas.height - 36, fy - 8));
                const clampedX = Math.max(48, Math.min(canvas.width - 48, fx));
                const chainSubtext =
                  sim.currentChain >= 2
                    ? `x${sim.currentChain} CHAIN${sim.isBoosting ? ' // BOOST' : ''}`
                    : sim.isBoosting
                    ? 'OVERDRIVE 1.5x'
                    : undefined;

                spawnFloatingText(
                  clampedX,
                  clampedY,
                  `+${pointsEarned}`,
                  sim.currentChain >= 5 ? '#FFB800' : '#00FF66',
                  chainSubtext,
                  sim.currentChain >= 4 ? 1.18 : 1.0
                );
              }

              // Spawn next primary green food immediately if primary was eaten
              if (eatenFood.type === 'PRIMARY_GREEN') {
                sim.primaryFoodCount += 1;
                spawnPrimaryGreenFood(false);

                // Every 5th primary green food spawns a 3-Orb Cluster Wave!
                if (sim.primaryFoodCount % 5 === 0) {
                  spawnClusterWave();
                  if (sim.gameState === 'PLAYING') {
                    spawnFloatingText(
                      canvas.width * 0.5,
                      canvas.height * 0.22,
                      'CLUSTER WAVE SPAWNED!',
                      '#00E5FF',
                      '3 BONUS GREEN CORES ACTIVE',
                      1.2
                    );
                  }
                }
              }
            }
          }
        }
      }

      // 3. Compute Camera Shake Offsets
      let shakeOffsetX = 0;
      let shakeOffsetY = 0;
      if (sim.shakeTrauma > 0.1) {
        const mag = sim.shakeTrauma * (canvas.width / 560);
        shakeOffsetX =
          (Math.random() * 2 - 1) * mag * 0.7 + sim.shakeDirX * mag * 0.5;
        shakeOffsetY =
          (Math.random() * 2 - 1) * mag * 0.7 + sim.shakeDirY * mag * 0.5;
      }

      // 4. Render 60fps Canvas Frame
      const ctx = canvas.getContext('2d');
      if (ctx) {
        renderGameCanvas({
          ctx,
          width: canvas.width,
          height: canvas.height,
          gridSize: GRID_SIZE,
          now,
          segments: sim.segments,
          prevSegments: sim.prevSegments,
          moveProgress: sim.moveProgress,
          direction: sim.direction,
          foods: sim.foods,
          particles: sim.particles,
          floatingTexts: sim.floatingTexts,
          shockwaves: sim.shockwaves,
          digestPulses: sim.digestPulses,
          isBoosting: sim.isBoosting,
          speedMultiplier: sim.speedMultiplier,
          currentChain: sim.currentChain,
          chainTimer: sim.chainTimer,
          borderPulse: sim.borderPulse,
          dangerPulse: sim.dangerPulse,
          shakeOffsetX,
          shakeOffsetY,
          isDying: sim.gameState === 'DYING',
          isDemo: sim.gameState === 'START',
        });
      }

      // 5. Sync React HUD State (~20Hz so React never bottlenecks the 60fps canvas)
      uiSyncAccumulator += dt;
      if (uiSyncAccumulator >= 0.05 && sim.gameState === 'PLAYING') {
        uiSyncAccumulator = 0;
        setStats({
          score: sim.score,
          foodEaten: sim.foodEaten,
          maxChain: sim.maxChain,
          currentChain: sim.currentChain,
          chainTimer: sim.chainTimer,
          length: sim.segments.length,
          speedMultiplier: sim.speedMultiplier,
          isBoosting: sim.isBoosting,
          closeCalls: sim.closeCalls,
          durationSec: Math.round((now - sim.runStartTime) / 1000),
        });
      }

      animationFrameId = requestAnimationFrame(stepSimulation);
    };

    animationFrameId = requestAnimationFrame(stepSimulation);
    return () => cancelAnimationFrame(animationFrameId);
  }, [
    arenaSizePx,
    computeAttractModeTurn,
    initArena,
    spawnClusterWave,
    spawnFloatingText,
    spawnParticle,
    spawnPrimaryGreenFood,
    spawnShockwave,
  ]);

  // Continuous Touch Swipe Gesture Handlers on Arena Canvas
  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const sim = simRef.current;
    if (sim.gameState !== 'PLAYING') return;
    sim.swipeStartX = e.clientX;
    sim.swipeStartY = e.clientY;
  };

  const handleCanvasPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const sim = simRef.current;
    if (
      sim.gameState !== 'PLAYING' ||
      sim.swipeStartX === null ||
      sim.swipeStartY === null
    ) {
      return;
    }

    const dx = e.clientX - sim.swipeStartX;
    const dy = e.clientY - sim.swipeStartY;
    const dist = Math.hypot(dx, dy);

    // Responsive 14px swipe threshold with anchor reset so continuous L-swipes execute multiple turns without lifting finger!
    if (dist >= 14) {
      if (Math.abs(dx) > Math.abs(dy)) {
        queueDirectionInput(dx > 0 ? 'RIGHT' : 'LEFT');
      } else {
        queueDirectionInput(dy > 0 ? 'DOWN' : 'UP');
      }
      sim.swipeStartX = e.clientX;
      sim.swipeStartY = e.clientY;
    }
  };

  const handleCanvasPointerUp = () => {
    simRef.current.swipeStartX = null;
    simRef.current.swipeStartY = null;
  };

  // UI Handlers
  const handleSelectPreset = (newPreset: SpeedPreset) => {
    sound.playButton();
    setPreset(newPreset);
    simRef.current.preset = newPreset;
  };

  const handleStartGame = () => {
    sound.playButton();
    initArena('PLAYING', preset);
  };

  const handleToggleMute = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const handleTogglePause = () => {
    sound.playButton();
    const sim = simRef.current;
    if (sim.gameState === 'PLAYING') {
      sim.gameState = 'PAUSED';
      sim.isBoosting = false;
      setGameState('PAUSED');
    } else if (sim.gameState === 'PAUSED') {
      sim.gameState = 'PLAYING';
      setGameState('PLAYING');
    }
  };

  const handleUpdateInitials = (newInitials: string) => {
    if (!newRecordId) return;
    const updated = updateHighScoreInitials(newRecordId, newInitials);
    setLeaderboard(updated);
  };

  const handleResetLeaderboard = () => {
    sound.playButton();
    const fresh = resetLeaderboardToDefault();
    setLeaderboard(fresh);
    setNewRecordId(null);
    setNewRecordRank(null);
  };

  const bestScore = leaderboard.length > 0 ? leaderboard[0].score : 0;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[100dvh] bg-[#08090D] text-[#F8FAFC] flex flex-col items-center justify-center overflow-hidden select-none px-2 py-1"
    >
      {/* Ambient Radial Cabinet Backlight */}
      <div
        className="pointer-events-none fixed inset-0 opacity-35"
        style={{
          background:
            'radial-gradient(circle at 50% 45%, rgba(0, 255, 102, 0.12), rgba(0, 229, 255, 0.04) 45%, transparent 75%)',
        }}
      />

      {/* Top Consolidated Telemetry Bar */}
      <TopHudBar
        stats={stats}
        bestScore={bestScore}
        gameState={gameState}
        preset={preset}
        isMuted={isMuted}
        showTouchControls={showTouchControls}
        onToggleMute={handleToggleMute}
        onTogglePause={handleTogglePause}
        onRestart={handleStartGame}
        onToggleTouchControls={() => {
          sound.playButton();
          setShowTouchControls((prev) => !prev);
        }}
      />

      {/* Central Square Playable Arena Frame */}
      <div
        className="relative rounded-md overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.85),0_0_35px_rgba(0,255,102,0.07)] shrink-0"
        style={{
          width: `${arenaSizePx}px`,
          height: `${arenaSizePx}px`,
        }}
      >
        {/* 60fps HTML5 Game Canvas */}
        <canvas
          ref={canvasRef}
          onPointerDown={handleCanvasPointerDown}
          onPointerMove={handleCanvasPointerMove}
          onPointerUp={handleCanvasPointerUp}
          onPointerCancel={handleCanvasPointerUp}
          className="block w-full h-full cursor-crosshair touch-none"
        />

        {/* Subtle CRT Scanline Texture Overlay */}
        <div className="pointer-events-none absolute inset-0 scanline-overlay opacity-25" />

        {/* Live Gameplay Micro-Banner for Controls during first 4 seconds of a run */}
        {gameState === 'PLAYING' && stats.foodEaten === 0 && (
          <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-[#11141D]/85 border border-[#00FF66]/40 text-[11px] font-mono-num text-[#00FF66] whitespace-nowrap animate-pulse shadow-[0_0_15px_rgba(0,255,102,0.25)]">
            EAT GREEN CORES • HOLD SHIFT / BOOST FOR 1.5x OVERDRIVE
          </div>
        )}

        {/* Start Screen Overlay (Over Live AI Demo Attract Mode) */}
        {gameState === 'START' && (
          <StartOverlay
            preset={preset}
            leaderboard={leaderboard}
            onSelectPreset={handleSelectPreset}
            onStartGame={handleStartGame}
          />
        )}

        {/* Pause State Overlay */}
        {gameState === 'PAUSED' && (
          <PauseOverlay
            stats={stats}
            isMuted={isMuted}
            onResume={handleTogglePause}
            onRestart={handleStartGame}
            onToggleMute={handleToggleMute}
            onQuitToTitle={() => {
              sound.playButton();
              initArena('START', preset);
            }}
          />
        )}

        {/* Game Over & Local High-Score Table Overlay */}
        {gameState === 'GAMEOVER' && (
          <GameOverOverlay
            stats={stats}
            leaderboard={leaderboard}
            newRecordId={newRecordId}
            newRecordRank={newRecordRank}
            initialCallsign={getSavedInitials()}
            deathReason={deathReason}
            onUpdateInitials={handleUpdateInitials}
            onRestart={handleStartGame}
            onQuitToTitle={() => {
              sound.playButton();
              initArena('START', preset);
            }}
            onResetLeaderboard={handleResetLeaderboard}
          />
        )}
      </div>

      {/* Optional On-Screen Touch D-Pad + Boost Dock */}
      {showTouchControls ? (
        <TouchControlDock
          currentDirection={activeDirection}
          isBoosting={stats.isBoosting}
          onDirectionInput={queueDirectionInput}
          onSetBoost={(active) => {
            simRef.current.isBoosting = active;
          }}
        />
      ) : (
        <footer className="w-full max-w-[660px] mt-2 px-2 flex items-center justify-between text-[11px] font-mono-num text-[#4A5368] shrink-0">
          <span>[WASD / ARROWS] STEER • [SHIFT / SPACE] BOOST</span>
          <span>[R] INSTANT RESTART • [P] PAUSE • [M] AUDIO</span>
        </footer>
      )}
    </div>
  );
}

export default App;
